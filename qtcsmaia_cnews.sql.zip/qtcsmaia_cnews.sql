-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 22, 2021 at 02:14 PM
-- Server version: 10.3.32-MariaDB-cll-lve
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `qtcsmaia_cnews`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `ID` bigint(20) NOT NULL,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `parent` bigint(20) NOT NULL,
  `author` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`ID`, `title`, `description`, `parent`, `author`) VALUES
(3, 'Kidney Health', 'Health is Wealth', 2, 1),
(8, 'Electronics tech', 'This is moved to electrical in technology', 0, 14),
(9, 'Test Electronics', 'This is test electronics', 0, 14),
(11, 'Industrial Electronics', 'Only for Industrial\r\n', 8, 14),
(12, 'U.S. News', 'This is a tag for U.S. Related News', 0, 25);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `ID` bigint(20) NOT NULL,
  `news_title` text NOT NULL,
  `news_content` longtext NOT NULL,
  `slug` text NOT NULL,
  `category` bigint(20) NOT NULL,
  `sub_category` bigint(20) NOT NULL,
  `excerpt` text NOT NULL,
  `featured_image` text NOT NULL,
  `author` bigint(20) NOT NULL,
  `news_status` varchar(20) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `views` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`ID`, `news_title`, `news_content`, `slug`, `category`, `sub_category`, `excerpt`, `featured_image`, `author`, `news_status`, `created_date`, `modified_date`, `views`) VALUES
(28, 'How to Install Wordpress', '<p>sdfsdfsdfs</p>', 'how-to-install-wordpress', 8, 11, 'sdfsdfsd', '/uploads/featured-images/world_of_stickers.png', 14, 'draft', '2021-11-27 23:00:00', '2021-11-14 17:38:00', 0),
(29, 'This is a news reader test...', '<p>This is a test of the writing system embedded in Curated News author/writer section.&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>What is Curated News?&nbsp;<span class=\"font-weight-bold\" style=\"box-sizing: border-box; margin: 0px; padding: 0px; font-weight: bold; font-size: 20px; caret-color: #212529; color: #212529; font-family: Poppins, sans-serif;\">The Curated News platform</span><span style=\"caret-color: #212529; color: #212529; font-family: Poppins, sans-serif; font-size: 15px; background-color: #ecf0f1;\">&nbsp;started out as an algorithm and eventually became a statistical process that has been ported to Android and iOS to give consumers misinformation-proof news. This platform provides a misinformation-proof framework at fractions of the cost of major companies, like Facebook. Our algorithmic process does not need a dedicated staff so interpretations of policy do not bog you down in potential legal matters or public controversey. Our unique methodology further helps to strengthen information flows by reinforcing habits that do not compromise democratic values, allowing diversity to shine outright. Curated News is immune to changes in the information environment, as we couple our platform with information consumption tools to help assist and strengthen your habits. Imagine consuming better information so you can earn more money on average and faster so you can save time. Imagine developing skillsets that actually help in your work while increasing your overall productivity. Curated News is more than just a platform; it is the future of information consumption for consumers who want a competitive edge without massive subscriptions that balloon in costs. For limited overhead, we have scaled information quality and equitized it. What Facebook did for social networking and Twitter and Instagram did for exposure, we are doing for content consumption.</span></p>', 'this-is-a-news-reader-test', 8, 0, 'This is a test of the news related system for this website. Let\'s see how well this works...', '/uploads/featured-images/landscape-6724639_960_720.jpg', 17, 'published', '2021-11-16 11:04:00', '2021-11-30 14:46:00', 0),
(30, 'This is another Test', '<p>Let\'s see if the 500 character word limit is enforced here.</p>', 'this-is-another-test', 8, 0, 'This is another test of our system to see if there is something we can do to make it better.', '/uploads/featured-images/Step 3.png', 25, 'published', '2021-12-07 09:16:00', '2021-12-07 14:16:00', 0),
(31, 'This is another test', '<p><span style=\"color: #212529; font-family: Poppins, sans-serif; font-size: 16px; background-color: #ecf0f1;\">Because our success is related to our statistical, privacy, and security techniques, we will not disclose the actual methodology for the Curated News platforms. We will only provide the framework behind the process as mentioned above. Our applications provide even more detail when you go to the \"FAQ/Questions?\" section that you will not get from this website. Whitepapers will be released in the future, detailing significant elements to our process for transparency.</span></p>', 'this-is-another-test-1', 8, 11, 'Because our success is related to our statistical, privacy, and security techniques, we will not disclose the actual methodology for the Curated News platforms. We will only provide the framework behind the process as mentioned above. Our applications provide even more detail when you go to the \"FAQ', '', 25, 'published', '2021-12-13 10:59:00', '2021-12-13 16:00:00', 0),
(32, 'Another Test', '<p>This is a test of the work count system.</p>', 'another-test', 8, 11, 'Here is another One', '', 25, 'published', '2021-12-13 11:09:00', '2021-12-13 16:10:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `ID` int(11) NOT NULL,
  `txnid` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `subscription_type` varchar(100) NOT NULL,
  `payment_status` varchar(255) NOT NULL,
  `item_number` text NOT NULL,
  `payment_title` text NOT NULL,
  `payment_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `expiry_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `payer_email` varchar(255) NOT NULL,
  `payer_id` varchar(255) NOT NULL,
  `subscr_id` varchar(255) NOT NULL,
  `paid_amount` float NOT NULL,
  `years` int(11) NOT NULL,
  `payment_date_paypal` text NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`ID`, `txnid`, `user_id`, `subscription_type`, `payment_status`, `item_number`, `payment_title`, `payment_date`, `expiry_date`, `payer_email`, `payer_id`, `subscr_id`, `paid_amount`, `years`, `payment_date_paypal`) VALUES
(12, '77E666269Y7228818', 18, 'Reader', 'Completed', 'UmVhZGVyfDE4fDE=', 'Reader subscription for the period of 1 year', '2021-12-05 11:02:24', '2022-12-05 06:02:24', 'sb-m0p47p8865826@personal.example.com', 'SSRRPZ892LUSS', 'I-TDV0CCBDJUHF', 15, 1, '03:01:43 Dec 05, 2021 PST'),
(13, '7WB24767RS512480X', 18, 'Author', 'Completed', 'QXV0aG9yfDE4fDE=', 'Author subscription for the period of 1 year', '2021-12-05 11:31:52', '2023-12-05 06:02:24', 'sb-m0p47p8865826@personal.example.com', 'SSRRPZ892LUSS', 'I-4V3T83UV116H', 25, 1, '03:31:12 Dec 05, 2021 PST'),
(14, '3P463621M4782823L', 18, 'Joint', 'Completed', 'Sm9pbnR8MTh8MQ==', 'Joint subscription for the period of 1 year', '2021-12-05 13:03:45', '2022-12-05 08:03:45', 'sb-m0p47p8865826@personal.example.com', 'SSRRPZ892LUSS', 'I-64VNVJ7DJ30A', 30, 1, '05:03:18 Dec 05, 2021 PST'),
(15, '0UR2448802577231E', 24, 'Joint', 'Completed', 'Sm9pbnR8MjR8MQ==', 'Joint subscription for the period of 1 year', '2021-12-05 17:17:07', '2022-12-05 12:17:07', 'sb-m0p47p8865826@personal.example.com', 'SSRRPZ892LUSS', 'I-5CTTKKVGVB7V', 30, 1, '09:16:27 Dec 05, 2021 PST'),
(16, '85F0557270153053F', 25, 'Joint', 'Completed', 'Sm9pbnR8MjV8MQ==', 'Joint subscription for the period of 1 year', '2021-12-07 03:48:06', '2022-12-06 22:48:06', 'sb-m0p47p8865826@personal.example.com', 'SSRRPZ892LUSS', 'I-WW091JFTFUMK', 30, 1, '19:47:05 Dec 06, 2021 PST'),
(17, '1T657767BM2155140', 26, 'Author', 'Completed', 'QXV0aG9yfDI2fDE=', 'Author subscription for the period of 1 year', '2021-12-12 08:37:24', '2022-12-12 03:37:24', 'sb-c4e9b8741019@personal.example.com', 'D83VA3KJT66W2', 'I-LUHD5GSDX0H2', 25, 1, '00:36:42 Dec 12, 2021 PST');

-- --------------------------------------------------------

--
-- Table structure for table `saved_news`
--

CREATE TABLE `saved_news` (
  `ID` bigint(20) NOT NULL,
  `reader` bigint(20) NOT NULL,
  `news` bigint(20) NOT NULL,
  `save_time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `saved_news`
--

INSERT INTO `saved_news` (`ID`, `reader`, `news`, `save_time`) VALUES
(27, 13, 29, '2021-11-29 21:26:03'),
(32, 18, 32, '2021-12-19 15:48:36'),
(33, 18, 31, '2021-12-22 14:08:12');

-- --------------------------------------------------------

--
-- Table structure for table `shared_news`
--

CREATE TABLE `shared_news` (
  `ID` bigint(20) NOT NULL,
  `share_from` bigint(20) NOT NULL,
  `share_to` bigint(20) NOT NULL,
  `news` bigint(20) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shared_news`
--

INSERT INTO `shared_news` (`ID`, `share_from`, `share_to`, `news`, `date`) VALUES
(1, 18, 1, 32, '2021-12-22 12:47:36'),
(2, 18, 18, 32, '2021-12-22 12:51:12');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `ID` int(11) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `user_name` varchar(30) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` text NOT NULL,
  `user_type` varchar(20) NOT NULL,
  `profile_image` text NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `subscription_status` tinyint(1) DEFAULT 0,
  `subscription_expiry` datetime DEFAULT NULL,
  `join_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `first_name`, `last_name`, `user_name`, `email`, `password`, `user_type`, `profile_image`, `is_active`, `subscription_status`, `subscription_expiry`, `join_date`) VALUES
(1, 'Test', 'test', 'test', 'test@test.com', '$2y$10$fDswJ60e7dctBgIHXf1DkOe6oKKVDzvknjXT00AYQSicUKuDwdEna', 'Both', '', 1, 0, NULL, '2021-10-24 18:17:04'),
(9, 'Abdul', 'Razzaq', 'theabdul', 'a.razzaq4085@gmail.com', '$2y$10$9DdRncCNYR03cBzJ4EOzVujnVpyMZHlrEJyFEIohd74Wx.VM/1gOK', 'Both', '', 1, 0, NULL, '2021-10-24 19:38:40'),
(11, 'Abdul', 'Razzaq', 'theabdult', 'test@gmail.com', '$2y$10$tCHr.qHtwkjPVsGuof7c0eKNkXm3NCH/Ps6o/Vnq3PDzIHYW89FlO', 'Both', '', 1, 0, NULL, '2021-10-24 19:50:30'),
(12, 'Test321', 'Test', 'Test321', 'test321@gmail.com', '$2y$10$SWOurMmXAo0lBEvceZdV/uCuEtat52zKqMSu5m2bYfp/cn.7HplCK', 'Both', '', 1, 0, NULL, '2021-10-25 08:06:02'),
(13, 'Matthew', 'Benchimol', 'mdbench', 'mdbench@outlook.com', '$2y$10$QBoPmRWsxh/hxEx4mWbVH.8xDhs7n9rOi3HlSkMEnSqxRS/ks3aZe', 'Both', '/uploads/profile-images/profile-13.png', 1, 0, NULL, '2021-10-27 14:09:25'),
(14, 'jaki', 'jaki', 'jaki4085', 'jaki@tgmail.com', '$2y$10$R6NJQAS3.GYEAI6rqF8NMOHILVmZu.bYwosHcl948U4vz8RIgSUaK', 'Both', '', 1, 0, NULL, '2021-10-27 19:50:18'),
(15, 'Abdul', 'Razzaq', 'jj', 'j@j.com', '$2y$10$ef9lj9jFPTOpsuWVTF9I8eyenrw6CIv2iNmAm8LseGUUW7FUc0rSq', 'Both', '', 1, 0, NULL, '2021-10-31 20:07:52'),
(16, 'abdul', 'razzaq', 'newuser', 'newuser@gmail.com', '$2y$10$VVncr.VshPJ6sc8uS.mB7uS1wFvHel9TKu1EozychkPdQZxKoBT.u', 'Both', '', 1, 0, NULL, '2021-11-04 19:07:28'),
(17, 'Matthew', 'Benchimol', 'mdbench2', 'mdbench@gmail.com', '$2y$10$TYymSAntdjcfCtdWtWVgNuBKDmNZe97Bns6p3omCVX8vXb.iq2D8K', 'Both', '/uploads/profile-images/profile-17.png', 1, 0, NULL, '2021-11-07 15:19:05'),
(18, 'Abdul J', 'Razzaq', 'theboth', 'theabdul.cyou@gmail.com', '$2y$10$qnLt.bv8ZCa0DVnReXZHH.T7QGqe9k5EdL7FpKTMH.yDygqiU3Qzm', 'Joint', '/uploads/profile-images/profile-18.png', 1, 1, '2022-12-05 13:03:45', '2021-11-21 10:06:16'),
(19, 'test12345', '12345', 'abc', 'abc@gmail.com', '$2y$10$b9mlt1tstzOazhHYsxNOxOuFjcvERk5Ru73v/b1sLU3.fnVSDjpeu', 'Both', '', 1, 0, NULL, '2021-11-23 05:57:15'),
(22, 'Abdul', 'Razzaq', 'thetest', 'thetest@gmail.com', '$2y$10$OKDlMvCcnHzNr0OVqRQEoeY/7pnLdzvBSywEdr4gGgwmdThHpSEme', 'Both', '/uploads/profile-images/profile-22.png', 1, 0, NULL, '0000-00-00 00:00:00'),
(23, 'Abdul', 'Razzaq', 'thereader', 'thereader@gmail.com', '$2y$10$iKwdA4sVfug2gQ2Gb6l/fO/bXN94bb1D2HQU5OWpRRgOYcLVcFaFO', 'Reader', '', 1, 0, NULL, '0000-00-00 00:00:00'),
(24, 'Abdul', 'Razzaq', 'developer', 'a.razzaq0085@gmail.com', '$2y$10$.eKcGLCsvGikUnOfjL1T6erjbI.swEuNtgJJeD8VZ5j8UpipGzrZK', 'Joint', '', 1, 1, '2022-12-05 17:17:07', '0000-00-00 00:00:00'),
(25, 'Matthew', 'Benchimol', 'mdbench3', 'mdbench87@yahoo.com', '$2y$10$CJR9ymhKN7Y1VhkZl0lAoOjpkvAI9njHUlGk.Zfxvu8EyCfCNZqy6', 'Joint', '/uploads/profile-images/profile-25.png', 1, 1, '2022-12-07 03:48:06', '0000-00-00 00:00:00'),
(26, 'Test', 'User', 'testuser1', 'test1@test.com', '$2y$10$J10di5MgvRMIrVyzldc3FebLH2o8S2SjiwVBcbxAhZbgBTxgGYZe2', 'Author', '', 1, 1, '2022-12-12 08:37:24', '0000-00-00 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `saved_news`
--
ALTER TABLE `saved_news`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `shared_news`
--
ALTER TABLE `shared_news`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `saved_news`
--
ALTER TABLE `saved_news`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `shared_news`
--
ALTER TABLE `shared_news`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
