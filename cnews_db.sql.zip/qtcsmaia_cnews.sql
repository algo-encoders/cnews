-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 27, 2021 at 09:37 PM
-- Server version: 10.3.31-MariaDB-cll-lve
-- PHP Version: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `qtcsmaia_cnews`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `ID` bigint(20) NOT NULL,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `parent` bigint(20) NOT NULL,
  `author` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`ID`, `title`, `description`, `parent`, `author`) VALUES
(3, 'Kidney Health', 'Health is Wealth', 2, 1),
(8, 'Electronics tech', 'This is moved to electrical in technology', 0, 14),
(9, 'Test Electronics', 'This is test electronics', 0, 14),
(11, 'Industrial Electronics', 'Only for Industrial\r\n', 8, 14);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `ID` bigint(20) NOT NULL,
  `news_title` text NOT NULL,
  `news_content` longtext NOT NULL,
  `slug` text NOT NULL,
  `category` bigint(20) NOT NULL,
  `sub_category` bigint(20) NOT NULL,
  `excerpt` text NOT NULL,
  `featured_image` text NOT NULL,
  `author` bigint(20) NOT NULL,
  `news_status` varchar(20) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `views` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`ID`, `news_title`, `news_content`, `slug`, `category`, `sub_category`, `excerpt`, `featured_image`, `author`, `news_status`, `created_date`, `modified_date`, `views`) VALUES
(28, 'How to Install Wordpress', '<p>sdfsdfsdfs</p>', 'how-to-install-wordpress', 8, 11, 'sdfsdfsd', '/uploads/featured-images/world_of_stickers.png', 14, 'draft', '2021-11-27 23:00:00', '2021-11-14 17:38:00', 0),
(29, 'This is a news reader test...', '<p>This is a test of the writing system embedded in Curated News author/writer section.&nbsp;</p>', 'this-is-a-news-reader-test', 8, 0, 'This is a test of the news related system for this website.', '/uploads/featured-images/landscape-6724639_960_720.jpg', 17, 'published', '2021-11-16 11:04:00', '2021-11-16 16:06:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `saved_news`
--

CREATE TABLE `saved_news` (
  `ID` bigint(20) NOT NULL,
  `reader` bigint(20) NOT NULL,
  `news` bigint(20) NOT NULL,
  `save_time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `saved_news`
--

INSERT INTO `saved_news` (`ID`, `reader`, `news`, `save_time`) VALUES
(26, 18, 29, '2021-11-21 15:22:30');

-- --------------------------------------------------------

--
-- Table structure for table `shared_news`
--

CREATE TABLE `shared_news` (
  `ID` bigint(20) NOT NULL,
  `share_from` bigint(20) NOT NULL,
  `share_to` bigint(20) NOT NULL,
  `news` bigint(20) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `ID` int(11) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `user_name` varchar(30) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` text NOT NULL,
  `user_type` varchar(20) NOT NULL,
  `profile_image` text NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `subscription_status` tinyint(1) NOT NULL,
  `subscription_expiry` datetime NOT NULL,
  `join_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `first_name`, `last_name`, `user_name`, `email`, `password`, `user_type`, `profile_image`, `is_active`, `subscription_status`, `subscription_expiry`, `join_date`) VALUES
(1, 'Test', 'test', 'test', 'test@test.com', '$2y$10$fDswJ60e7dctBgIHXf1DkOe6oKKVDzvknjXT00AYQSicUKuDwdEna', 'Admin', '', 1, 1, '2022-02-28 00:00:00', '2021-10-24 18:17:04'),
(9, 'Abdul', 'Razzaq', 'theabdul', 'a.razzaq4085@gmail.com', '$2y$10$9DdRncCNYR03cBzJ4EOzVujnVpyMZHlrEJyFEIohd74Wx.VM/1gOK', 'Author', '', 1, 1, '2021-11-24 19:38:40', '2021-10-24 19:38:40'),
(11, 'Abdul', 'Razzaq', 'theabdult', 'test@gmail.com', '$2y$10$tCHr.qHtwkjPVsGuof7c0eKNkXm3NCH/Ps6o/Vnq3PDzIHYW89FlO', 'Reader', '', 1, 1, '2021-11-24 19:50:30', '2021-10-24 19:50:30'),
(12, 'Test321', 'Test', 'Test321', 'test321@gmail.com', '$2y$10$SWOurMmXAo0lBEvceZdV/uCuEtat52zKqMSu5m2bYfp/cn.7HplCK', 'Author', '', 1, 1, '2021-11-25 08:06:02', '2021-10-25 08:06:02'),
(13, 'Matthew', 'Benchimol', 'mdbench', 'mdbench@outlook.com', '$2y$10$QBoPmRWsxh/hxEx4mWbVH.8xDhs7n9rOi3HlSkMEnSqxRS/ks3aZe', 'Reader', '', 1, 1, '2021-11-27 14:09:25', '2021-10-27 14:09:25'),
(14, 'jaki', 'jaki', 'jaki4085', 'jaki@tgmail.com', '$2y$10$R6NJQAS3.GYEAI6rqF8NMOHILVmZu.bYwosHcl948U4vz8RIgSUaK', 'Author', '', 1, 1, '2021-11-27 19:50:18', '2021-10-27 19:50:18'),
(15, 'Abdul', 'Razzaq', 'jj', 'j@j.com', '$2y$10$ef9lj9jFPTOpsuWVTF9I8eyenrw6CIv2iNmAm8LseGUUW7FUc0rSq', 'Reader', '', 1, 1, '2021-12-01 20:07:52', '2021-10-31 20:07:52'),
(16, 'abdul', 'razzaq', 'newuser', 'newuser@gmail.com', '$2y$10$VVncr.VshPJ6sc8uS.mB7uS1wFvHel9TKu1EozychkPdQZxKoBT.u', 'Reader', '', 1, 1, '2021-12-04 19:07:28', '2021-11-04 19:07:28'),
(17, 'Matthew', 'Benchimol', 'mdbench2', 'mdbench@gmail.com', '$2y$10$TYymSAntdjcfCtdWtWVgNuBKDmNZe97Bns6p3omCVX8vXb.iq2D8K', 'Author', '', 1, 1, '2021-12-07 15:19:05', '2021-11-07 15:19:05'),
(18, 'Abdul J', 'Razzaq', 'theboth', 'theabdul.cyou@gmail.com', '$2y$10$qnLt.bv8ZCa0DVnReXZHH.T7QGqe9k5EdL7FpKTMH.yDygqiU3Qzm', 'Both', '/uploads/profile-images/profile-18.png', 1, 1, '2021-12-21 10:06:16', '2021-11-21 10:06:16'),
(19, 'test12345', '12345', 'abc', 'abc@gmail.com', '$2y$10$b9mlt1tstzOazhHYsxNOxOuFjcvERk5Ru73v/b1sLU3.fnVSDjpeu', 'Both', '', 1, 1, '2021-12-23 05:57:15', '2021-11-23 05:57:15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `saved_news`
--
ALTER TABLE `saved_news`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `shared_news`
--
ALTER TABLE `shared_news`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `saved_news`
--
ALTER TABLE `saved_news`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `shared_news`
--
ALTER TABLE `shared_news`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
